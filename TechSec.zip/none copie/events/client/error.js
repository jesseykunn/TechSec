module.exports = client => {
    console.error();
}
