module.exports = client => {
    console.warn();
}

